# BearCave Style Library

This folder contains modular "house style" prompt fragments for use with BearCave nodes in ComfyUI.

Each `.txt` file should contain a short, descriptive string defining a consistent artistic style, tone, lighting, and palette.

## Usage
Load these in ComfyUI via a `LoadTextFile` node or through the custom `BearStyleLibrary` node (coming soon).

## Example Files
- `wayne_reynolds.txt` – bold, cinematic fantasy art
- `storybook_fantasy.txt` – soft, whimsical, illustrated style
- `painterly_dark.txt` – chiaroscuro, oil-paint realism
- `eldritch_arcana.txt` – haunted, magical, arcane chaos
- `sci_fi_neonpunk.txt` – neon glow, high contrast, urban tech
